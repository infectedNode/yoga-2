<!DOCTYPE html>
	<!--[if IE 8]>
		<html xmlns="http://www.w3.org/1999/xhtml" class="ie8" lang="en-US">
	<![endif]-->
	<!--[if !(IE 8) ]><!-->
		<html xmlns="http://www.w3.org/1999/xhtml" lang="en-US">
	<!--<![endif]-->
	<head>
	<meta http-equiv="Content-Type" content="text/html; charset=UTF-8" />
	<title>Log In &lsaquo; Om Yoga International &#8211; Blog &#8212; WordPress</title>
	<link rel='dns-prefetch' href='//s.w.org' />
<script type='text/javascript' src='https://www.yogainindia.co.in/blogyoga/wp-includes/js/jquery/jquery.js?ver=1.12.4'></script>
<script type='text/javascript' src='https://www.yogainindia.co.in/blogyoga/wp-includes/js/jquery/jquery-migrate.min.js?ver=1.4.1'></script>
<script type='text/javascript' src='https://www.yogainindia.co.in/blogyoga/wp-content/plugins/wp-customer-reviews/js/wp-customer-reviews.js?ver=3.1.9'></script>
<link rel='stylesheet' id='wp-customer-reviews-3-frontend-css'  href='https://www.yogainindia.co.in/blogyoga/wp-content/plugins/wp-customer-reviews/css/wp-customer-reviews-generated.css?ver=3.1.9' type='text/css' media='all' />
<link rel='stylesheet' id='dashicons-css'  href='https://www.yogainindia.co.in/blogyoga/wp-includes/css/dashicons.min.css?ver=5.0.3' type='text/css' media='all' />
<link rel='stylesheet' id='buttons-css'  href='https://www.yogainindia.co.in/blogyoga/wp-includes/css/buttons.min.css?ver=5.0.3' type='text/css' media='all' />
<link rel='stylesheet' id='forms-css'  href='https://www.yogainindia.co.in/blogyoga/wp-admin/css/forms.min.css?ver=5.0.3' type='text/css' media='all' />
<link rel='stylesheet' id='l10n-css'  href='https://www.yogainindia.co.in/blogyoga/wp-admin/css/l10n.min.css?ver=5.0.3' type='text/css' media='all' />
<link rel='stylesheet' id='login-css'  href='https://www.yogainindia.co.in/blogyoga/wp-admin/css/login.min.css?ver=5.0.3' type='text/css' media='all' />
	<meta name='robots' content='noindex,noarchive' />
	<meta name='referrer' content='strict-origin-when-cross-origin' />
		<meta name="viewport" content="width=device-width" />
		</head>
	<body class="login login-action-login wp-core-ui  locale-en-us">
		<div id="login">
		<h1><a href="https://wordpress.org/" title="Powered by WordPress" tabindex="-1">Powered by WordPress</a></h1>
	
<form name="loginform" id="loginform" action="https://www.yogainindia.co.in/blogyoga/wp-login.php" method="post">
	<p>
		<label for="user_login">Username or Email Address<br />
		<input type="text" name="log" id="user_login" class="input" value="" size="20" /></label>
	</p>
	<p>
		<label for="user_pass">Password<br />
		<input type="password" name="pwd" id="user_pass" class="input" value="" size="20" /></label>
	</p>
		<p class="forgetmenot"><label for="rememberme"><input name="rememberme" type="checkbox" id="rememberme" value="forever"  /> Remember Me</label></p>
	<p class="submit">
		<input type="submit" name="wp-submit" id="wp-submit" class="button button-primary button-large" value="Log In" />
		<input type="hidden" name="redirect_to" value="https://www.yogainindia.co.in/blogyoga/wp-admin/" />
		<input type="hidden" name="testcookie" value="1" />
	</p>
</form>

<p id="nav">
<a href="https://www.yogainindia.co.in/blogyoga/wp-login.php?action=register">Register</a> | 	<a href="https://www.yogainindia.co.in/blogyoga/wp-login.php?action=lostpassword">Lost your password?</a>
</p>

<script type="text/javascript">
function wp_attempt_focus(){
setTimeout( function(){ try{
d = document.getElementById('user_login');
d.focus();
d.select();
} catch(e){}
}, 200);
}

wp_attempt_focus();
if(typeof wpOnload=='function')wpOnload();
</script>

	<p id="backtoblog"><a href="https://www.yogainindia.co.in/blogyoga/">&larr; Back to Om Yoga International &#8211; Blog</a></p>
		
	</div>

	
	<script>        
        var wppbRecaptchaCallback = function() {
            if( typeof window.wppbRecaptchaCallbackExecuted == "undefined" ){//see if we executed this before
                jQuery(".wppb-recaptcha-element").each(function(){
                    recID = grecaptcha.render( jQuery(this).attr("id"), {
                        "sitekey" : "6Lds_1oUAAAAAEbyThQwk0mR-yHl5mQZdVKaKrs0",                        
                        "error-callback": wppbRecaptchaInitializationError,
                                                
                     });                 
                });
                window.wppbRecaptchaCallbackExecuted = true;//we use this to make sure we only run the callback once
            }
        };
        
        /* the callback function for when the captcha does not load propperly, maybe network problem or wrong keys  */
        function wppbRecaptchaInitializationError(){            
            window.wppbRecaptchaInitError = true;
            //add a captcha field so we do not just let the form submit if we do not have a captcha response
            jQuery( ".wppb-recaptcha-element" ).after('<input type="hidden" id="wppb_recaptcha_load_error" name="wppb_recaptcha_load_error" value="8db9eb943d" />');
        }
        
        /* compatibility with other plugins that may include recaptcha with an onload callback. if their script loads first then our callback will not execute so call it explicitly  */        
        jQuery( window ).on( "load", function() {
            wppbRecaptchaCallback();
        });
    </script><script src="https://www.google.com/recaptcha/api.js?onload=wppbRecaptchaCallback&render=explicit" async defer></script>	<div class="clear"></div>
	</body>
	</html>
	